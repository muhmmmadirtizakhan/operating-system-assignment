#include<iostream>
using namespace std;
int main(){
cout<<"Muhammad Irtiza Khan - B24110106039";
return 0;
}
