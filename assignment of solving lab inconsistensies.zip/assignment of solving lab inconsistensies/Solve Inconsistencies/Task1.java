import java.util.concurrent.Semaphore;

// Task 1: fixing the lost updates with a semaphore
public class Task1 implements Runnable {

    static final int THREADS = 4;
    static final int LOOPS = 1_000_000;

    static long shared = 0;                      // heap, all threads touch it

    // only 1 permit, so it works like a lock (binary semaphore)
    static final Semaphore mutex = new Semaphore(1);

    private final int id;

    Task1(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        long local = 0;                          // private to this thread

        for (int i = 0; i < LOOPS; i++) {
            try {
                mutex.acquire();                 // take the permit, wait if someone has it
                try {
                    shared++;                    // critical section, one thread at a time
                } finally {
                    mutex.release();             // always give it back, even if something fails
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            local++;                             // no lock needed, nobody else sees local
        }

        System.out.printf("worker %d  local=%d%n", id, local);
    }

    public static void main(String[] args) throws Exception {
        Thread[] workers = new Thread[THREADS];

        for (int i = 0; i < THREADS; i++) {
            workers[i] = new Thread(new Task1(i), "worker-" + i);
        }
        for (Thread w : workers) {
            w.start();
        }
        for (Thread w : workers) {
            w.join();
        }

        long expected = (long) THREADS * LOOPS;
        System.out.printf("shared = %d   (expected %d, lost %d)%n",
                shared, expected, expected - shared);
    }
}
