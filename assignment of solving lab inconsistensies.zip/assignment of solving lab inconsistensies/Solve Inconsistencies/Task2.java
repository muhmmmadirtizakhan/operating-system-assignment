// Task 2: fixing the lost updates with Java's built-in monitor (synchronized)
public class Task2 implements Runnable {

    static final int THREADS = 4;
    static final int LOOPS = 1_000_000;

    static long shared = 0;                      // heap, all threads touch it

    private final int id;

    Task2(int id) {
        this.id = id;
    }

    // static synchronized -> a thread must hold the monitor of the Task2 class
    // to get in. The others wait outside until the owner leaves the method.
    static synchronized void increment() {
        shared++;
    }

    @Override
    public void run() {
        long local = 0;                          // private to this thread

        for (int i = 0; i < LOOPS; i++) {
            increment();
            local++;                             // no lock needed here
        }

        System.out.printf("worker %d  local=%d%n", id, local);
    }

    public static void main(String[] args) throws Exception {
        Thread[] workers = new Thread[THREADS];

        for (int i = 0; i < THREADS; i++) {
            workers[i] = new Thread(new Task2(i), "worker-" + i);
        }
        for (Thread w : workers) {
            w.start();
        }
        for (Thread w : workers) {
            w.join();
        }

        long expected = (long) THREADS * LOOPS;
        System.out.printf("shared = %d   (expected %d, lost %d)%n",
                shared, expected, expected - shared);
    }
}
