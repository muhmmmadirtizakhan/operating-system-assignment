public class Task2 {

    static final int THREADS = 4;
    static final int LOOPS = 1_000_000;

    // one copy only, it lives on the heap and all 4 threads use it
    static long shared = 0;

    static class Worker implements Runnable {
        private final int id;

        Worker(int id) {
            this.id = id;
        }

        @Override
        public void run() {
            long local = 0;            // each thread gets its own, on its own stack

            for (int i = 0; i < LOOPS; i++) {
                shared++;              // not atomic (read, add, write) so updates get lost
                local++;
            }

            System.out.printf("worker %d  local=%d%n", id, local);
        }
    }

    public static void main(String[] args) throws Exception {
        Thread[] workers = new Thread[THREADS];

        for (int i = 0; i < THREADS; i++) {
            workers[i] = new Thread(new Worker(i), "worker-" + i);
        }
        for (Thread w : workers) {
            w.start();
        }
        for (Thread w : workers) {
            w.join();
        }

        long expected = (long) THREADS * LOOPS;
        System.out.printf("shared = %d   (expected %d, lost %d)%n",
                shared, expected, expected - shared);
    }
}
