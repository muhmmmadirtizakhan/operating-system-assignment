public class Task4 {

    // does nothing except wait for one second, no CPU work at all
    static class Sleeper implements Runnable {
        @Override
        public void run() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    // gives back a new (not started) thread of the kind asked for
    static Thread makeThread(String mode) {
        if (mode.equals("platform")) {
            return new Thread(new Sleeper());
        }
        if (mode.equals("virtual")) {
            return Thread.ofVirtual().unstarted(new Sleeper());
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2 || makeThread(args[0]) == null) {
            System.out.println("Usage: java Task4.java <platform|virtual> <count>");
            return;
        }

        String mode = args[0];
        int n = Integer.parseInt(args[1]);

        Thread[] all = new Thread[n];

        long begin = System.nanoTime();

        for (int i = 0; i < n; i++) {
            all[i] = makeThread(mode);
            all[i].start();
        }
        for (int i = 0; i < n; i++) {
            all[i].join();
        }

        long finish = System.nanoTime();
        double seconds = (finish - begin) / 1_000_000_000.0;

        System.out.printf("mode=%s  n=%d  wall=%.3f seconds%n", mode, n, seconds);
    }
}
