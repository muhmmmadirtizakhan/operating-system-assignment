import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Task5 {

    static final int TASKS = 1000;

    static class Sleeper implements Runnable {
        @Override
        public void run() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    // picks the executor from the command line argument
    static ExecutorService pickExecutor(String mode) {
        switch (mode) {
            case "fixed8":   return Executors.newFixedThreadPool(8);
            case "fixed200": return Executors.newFixedThreadPool(200);
            case "virtual":  return Executors.newVirtualThreadPerTaskExecutor();
            default:         return null;
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java Task5.java <fixed8|fixed200|virtual>");
            return;
        }

        String mode = args[0];
        ExecutorService executor = pickExecutor(mode);
        if (executor == null) {
            System.out.println("Usage: java Task5.java <fixed8|fixed200|virtual>");
            return;
        }

        long begin = System.nanoTime();

        for (int i = 0; i < TASKS; i++) {
            executor.submit(new Sleeper());
        }
        executor.shutdown();            // no more tasks, but the queued ones still run

        if (!executor.awaitTermination(10, TimeUnit.MINUTES)) {
            System.out.println("Tasks did not finish within the timeout.");
            executor.shutdownNow();
            return;
        }

        long finish = System.nanoTime();
        double seconds = (finish - begin) / 1_000_000_000.0;

        System.out.printf("mode=%s  tasks=%d  wall=%.3f seconds%n", mode, TASKS, seconds);
    }
}
