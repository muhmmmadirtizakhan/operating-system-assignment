public class Task1 {

    static final int THREAD_COUNT = 4;

    static class Worker implements Runnable {
        private final int id;          // every worker keeps its own copy of id

        Worker(int id) {
            this.id = id;
        }

        @Override
        public void run() {
            Thread me = Thread.currentThread();
            System.out.printf("task %d  name=%s  id=%d  virtual=%b%n",
                    id, me.getName(), me.threadId(), me.isVirtual());
        }
    }

    public static void main(String[] args) throws Exception {
        Thread[] workers = new Thread[THREAD_COUNT];

        // just creating the Thread objects, nothing is running yet
        for (int i = 0; i < THREAD_COUNT; i++) {
            workers[i] = new Thread(new Worker(i), "worker-" + i);
        }

        // start() is the call that really creates the OS thread
        for (Thread w : workers) {
            w.start();
        }

        // main waits here until every worker is finished
        for (Thread w : workers) {
            w.join();
        }

        System.out.println("all joined");
    }
}
