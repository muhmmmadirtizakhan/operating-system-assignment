
# Lab 4 — Observations Log

## Task 1 — Start and join

Ran the working `start`/`join` version 10 times: worker print order varied across runs (e.g. run 3 printed `task 1` before `task 0`), confirming thread scheduling is non‑deterministic; `all joined` never appeared before a worker line, since `join()` blocks main until every worker has finished.

**Break (a) — `t[i].run()` instead of `t[i].start()`:** every line printed `name=main id=1 virtual=false`. Calling `run()` directly executes the method as an ordinary call on the *current* thread — no new OS thread is ever created — so all four "workers" just ran sequentially inside `main`.

**Break (b) — shared `Counter`:** all four lines printed `task 4`. `Worker` held a reference to one shared `Counter` object, and `main` finished incrementing `counter.value` to 4 (in the object‑creation loop) before any thread was started, so every thread read the same final shared value instead of its own id. This is the reference‑vs‑value lesson: a field holding a *reference* to shared mutable state gives every thread the same (changing) value, while a field holding an `int` by value — the original Task 1 — gives each thread its own independent copy.

## Task 2 — Shared and private

Ran 5 times. `local` was exactly `1,000,000` on every thread, every run (perfectly stable). `shared` varied every run and was always well below the expected `4,000,000`:

| Run | shared |
|---|---|
| 1 | 2,818,073 |
| 2 | 3,556,101 |
| 3 | 3,121,015 |
| 4 | 2,603,637 |
| 5 | 3,347,658 |

`local` is stable because it's a local variable living on each thread's own private stack — there's no sharing and no race. `shared` is unstable and always below the expected 4,000,000 because `shared++` is a non‑atomic read‑modify‑write operation; concurrent threads can interleave and overwrite each other's updates, causing lost updates — exactly the race this task asks us to observe and leave unfixed. (`shared` is shared class state on the heap, whereas `local` is a separate variable per worker on that worker's own stack — the location explains *where* each variable lives, but the race itself comes from the unsynchronized read‑modify‑write, not from being `static` per se.)

## Task 3 — Partition and time

Implemented `SliceSum implements Callable<Double>` with `data`/`lo`/`hi` bounds as fields, built a `List<Callable<Double>>` of size T, ran it via `pool.invokeAll(tasks)` on a fixed pool, discarded two warm‑up `invokeAll` calls before timing (i.e. 3 internal runs per program execution, last one kept), and called `pool.shutdown()` after collecting results. Measured T = 1, 2, 4, 8, and 16 (cores × 4, since `nproc` = 4); each T was also run across 3 separate program executions and averaged, JVM launched with `-Xmx3g`.

| T | Time (ms) | Speedup = time(1) ÷ time(T) | Efficiency = speedup ÷ T |
|---|---|---|---|
| 1 | 360.71 | 1.00 | 1.00 |
| 2 | 181.55 | 1.99 | 0.99 |
| 4 | 132.50 | 2.72 | 0.68 |
| 8 | 234.01 | 1.54 | 0.19 |
| 16 (cores×4) | 178.70* | 2.02* | 0.13* |

*The first T=16 run (280.743 ms) is a clear outlier against its other two runs (121.846 ms, 133.507 ms). Excluding it, the 2‑run average is 127.68 ms → speedup 2.83, efficiency 0.18.

**At which T does speedup first fall clearly short of T?** Already at T=2 it's essentially perfect (1.99 vs ideal 2.00), but the *clear* shortfall starts at T=4: measured speedup is 2.72 against an ideal of 4.00. `nproc` = 4 counts logical processors, which may include hyperthreads, so four threads do not necessarily get four fully independent cores. The loop is also memory‑bound (each thread streams through its part of a 1.6 GB array), which limits scaling further.

**Efficiency drop:** efficiency is almost perfect at T=2 (0.99), falls to 0.68 at T=4, and collapses to 0.19 at T=8 and about 0.13–0.18 at T=16. Every extra thread adds the same fixed overhead (creating tasks, handing out slices, collecting futures) while the serial part stays the same, and once T goes past the 4 logical CPUs the extra threads only compete for the same CPUs, so each thread's useful share shrinks and speedup stops growing.

**Amdahl's law, solved for f using the T=4 row:** speedup = 1 / ((1 − f) + f/T). With T = 4 and measured speedup = 2.72:

```
2.72 = 1 / ((1 − f) + f/4)
(1 − f) + f/4 = 1 / 2.72 = 0.3676
1 − 0.75f = 0.3676
0.75f = 0.6324
f ≈ 0.843
```

So about 84% of Task 3's work is estimated to be parallelizable, with the remaining ~16% effectively serial (array setup, task/future bookkeeping, combining results).

**cores×4 (T=16) vs. the best row:** the best row is T=4 (132.50 ms, speedup 2.72). T=16 (178.70 ms average, or 127.68 ms excluding the outlier) is roughly the same as or slightly worse than T=4 — not meaningfully faster despite using 4× more threads. Adding threads past the hardware's real capacity (4 logical CPUs) doesn't add compute capacity, it only adds scheduling and context‑switch overhead, so wall time plateaus or gets worse instead of continuing to improve.

## Task 4 — Where platform threads run out

| Mode | n | Wall time | Outcome |
|---|---|---|---|
| platform | 10,000 | 7.413 s | Completed — no `OutOfMemoryError` at this n |
| virtual | 10,000 | 1.366 s | Completed — close to the 1 s ideal |
| virtual | 1,000,000 | 10.026 s | Completed — no `OutOfMemoryError` |

Additional data points recorded beyond the required rows: platform scaled roughly linearly with n (1,000 → 1.505 s, 100,000 → 71.192 s, 1,000,000 → 708.185 s), and on this machine (3.8 GiB RAM) `platform` only threw `OutOfMemoryError: Java heap space` at n = 10,000,000; `virtual` reported the same `OutOfMemoryError: Java heap space` at that same n — so at 10,000,000 concurrent tasks, this workload exceeded the memory available to the Java process in both modes.

Every task sleeps exactly one second, but total wall time is not n seconds because a sleeping task holds no CPU — it's simply parked — so many tasks can be "in flight" concurrently; wall time is governed by how much concurrency the runtime can actually sustain, not by the sum of the individual sleeps. Virtual threads approach the ~1 s ideal because the JVM multiplexes many virtual threads over a small number of carrier (platform) threads and unmounts a virtual thread from its carrier while it's parked in `sleep()`, so 10,000 or even 1,000,000 virtual threads can all be "sleeping" at once on just a handful of real threads. Platform threads cannot approach that ideal because each one is a real OS thread with its own ~1 MB stack and a kernel scheduling entry; creating and context‑switching thousands of them is expensive regardless of the fact that they're merely sleeping, so wall time grows with n instead of staying near 1 s.

## Task 5 — Pool starvation

| Executor | Wall time (avg of 3) | Predicted time |
|---|---|---|
| Fixed pool, 8 threads | 125.1 s (125.054 / 125.112 / 125.052) | ⌈1000/8⌉ × 1 s = 125 s |
| Fixed pool, 200 threads | 5.19 s (5.167 / 5.283 / 5.125) | ⌈1000/200⌉ × 1 s = 5 s |
| Virtual thread per task | 1.10 s (1.145 / 1.070 / 1.082) | ~1 s |

All three measured times closely matched their predictions. With a fixed pool, only `poolSize` tasks can run at once and the rest queue; 1,000 one‑second tasks over a pool of 8 must run in ⌈1000/8⌉ = 125 sequential batches (≈125 s), and over a pool of 200 in ⌈1000/200⌉ = 5 batches (≈5 s) — this is pure queueing delay, not computation, since a `Sleeper` does no CPU work. The virtual‑thread‑per‑task executor has no fixed pool size to queue behind: every task gets its own cheap virtual thread, and they all block in `sleep()` concurrently while unmounted from the handful of real carrier threads, so all 1,000 finish in essentially one second. Pool size is the wrong dial for blocking work because turning it up just trades one bottleneck (queueing) for another (thousands of expensive OS threads doing nothing but sleep) — the actual fix is decoupling task count from OS thread count entirely, which is what virtual threads do.

**How large would the fixed pool need to be to match the virtual‑thread time (~1 s)?** At least 1,000 — one thread per task — so every `Sleeper` can run in a single concurrent batch instead of queueing (⌈1000/poolSize⌉ × 1 s only reaches ~1 s once `poolSize ≥ 1000`). Growing the pool that large is a bad way to get there: each of those 1,000 threads is a real OS thread reserving its own ~1 MB stack and a kernel scheduling entry, purely to sit parked in `sleep()` doing nothing — expensive just to buy concurrency. Virtual threads get the same concurrency without that cost, since a parked virtual thread doesn't tie up an OS thread at all; it's unmounted from its carrier while sleeping, so thousands of them can be idle at once on a handful of real threads.

