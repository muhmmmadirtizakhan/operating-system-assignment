import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Task3 {

    static final int SIZE = 200_000_000;

    // adds up one slice of the array, the bounds are stored in fields
    static class SliceSum implements Callable<Double> {
        private final double[] data;
        private final int lo;
        private final int hi;

        SliceSum(double[] data, int lo, int hi) {
            this.data = data;
            this.lo = lo;
            this.hi = hi;
        }

        @Override
        public Double call() {
            double sum = 0.0;
            for (int i = lo; i < hi; i++) {
                sum += data[i];
            }
            return sum;
        }
    }

    public static void main(String[] args) throws Exception {
        int T = Integer.parseInt(args[0]);      // number of threads

        double[] data = new double[SIZE];
        Arrays.fill(data, 1.0);

        ExecutorService pool = Executors.newFixedThreadPool(T);

        // one task per slice, the last one also takes the leftover
        int chunk = SIZE / T;
        List<Callable<Double>> tasks = new ArrayList<>();
        for (int i = 0; i < T; i++) {
            int lo = i * chunk;
            int hi = (i == T - 1) ? SIZE : lo + chunk;
            tasks.add(new SliceSum(data, lo, hi));
        }

        // first two runs are only to warm up the JIT, we ignore them
        for (int warm = 0; warm < 2; warm++) {
            pool.invokeAll(tasks);
        }

        // timed run: submit -> all results collected
        long begin = System.nanoTime();
        List<Future<Double>> futures = pool.invokeAll(tasks);
        double total = 0.0;
        for (Future<Double> f : futures) {
            total += f.get();
        }
        long finish = System.nanoTime();

        pool.shutdown();

        double ms = (finish - begin) / 1_000_000.0;
        System.out.printf("threads=%d  sum=%.1f  time=%.3f ms%n", T, total, ms);
    }
}
